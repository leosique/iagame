using System.Drawing;

public class TreviEdPlayer : Player
{
    public TreviEdPlayer(PointF location) : 
        base(location, Color.Black, Color.Blue, "TreviJalma") { }

    int i = 0;
    int searchindex = 0;
    int frame = 0;
    int points = 0;
    PointF? enemy = null;

    protected override void loop()
    {
        frame++;
        StartTurbo();
        if (enemy == null && Energy >= 50)
            InfraRedSensor(5f * i++);
        else if(Energy < 50 ){
            StopMove();
            if (EntitiesInAccurateSonar.Count == 0)
            {
                AccurateSonar();
            }
            else if (FoodsInInfraRed.Count == 0)
            {
                InfraRedSensor(EntitiesInAccurateSonar[searchindex++ % EntitiesInAccurateSonar.Count]);
            }
            else
            {
                StartMove(FoodsInInfraRed[0]);
                if (Points != points)
                {
                    StartTurbo();
                    StrongSonar();
                    StopMove();
                    ResetInfraRed();
                    ResetSonar();
                }
            }
        }
        else if (enemy != null && Energy >= 50)
        {
            InfraRedSensor(enemy.Value);
            if (enemy.Value.X - this.Location.X > 400 ||
                enemy.Value.Y - this.Location.Y > 400)
                StartMove(enemy.Value);
            else
            {
                StopMove();
                if (i++ % 10 == 0)
                Shoot(enemy.Value);
            }
        }

        if (EnemiesInInfraRed.Count > 0)
        {
            enemy = EnemiesInInfraRed[0];
        }
        else
        {
            enemy = null;
        }
    }
}